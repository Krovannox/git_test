# odin-recipes
The objective of the project is to create a recipes web layout using only HTML.
Five recipes pages where created, using CLI to move the images downloaded to the appropiate folder,
and to create the .html files.
Each .html file was generated manually, meaning there was no copy paste nor shorcuts for the boilerplate.
Each recipe page contains the title of the recipe, an image of it with a short description, a brief text
about the dish, data about the dish preparation, ingredients presented by unorder list and steps presented
with order list. At the end of each recipe page a link to return to the main page was created.